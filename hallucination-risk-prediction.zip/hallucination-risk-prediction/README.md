# Pre-Inference Hallucination Risk Prediction in LLMs

> A lightweight, model-agnostic safety layer that predicts hallucination risk **before** inference starts — so you can act on it, not clean it up.

[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)
[![Paper](https://img.shields.io/badge/paper-PDF-red.svg)](paper/main.pdf)

---

## Overview

Most hallucination mitigation strategies are **reactive** — they let the model generate a response and then audit it for accuracy. This doubles latency and cost for every query.

This project proposes a **pre-inference** approach: analyse the user's *prompt* to predict whether it is likely to cause a hallucination, before any generation happens.

```
User Prompt
    │
    ▼
DeBERTa Encoder  ──►  [CLS] Embedding  ──►  MLP Classifier
                                                  │
                         ┌────────────────────────┤
                         ▼                        ▼
                    Low Risk               High / Medium Risk
                    (pass to LLM)         (apply mitigation:
                                           RAG / rewrite / route)
```

Our DeBERTa-v3-based classifier achieves **81.3% accuracy** and **0.80 F1-score** with only **~12ms latency** — less than 1% overhead on a typical LLM pipeline.

---

## Key Results

| Model | Accuracy | Precision | Recall | F1 |
|---|---|---|---|---|
| Majority Class Baseline | 50.0% | 0.50 | 1.00 | 0.67 |
| Prompt Length Baseline | 52.3% | 0.54 | 0.67 | 0.60 |
| Keyword-based | 58.7% | 0.62 | 0.71 | 0.66 |
| TF-IDF + Logistic Regression | 65.4% | 0.68 | 0.74 | 0.71 |
| **DeBERTa-v3 (Ours)** | **81.3%** | **0.78** | **0.75** | **0.80** |

**High-Risk Recall: 0.88** — the model rarely misses a dangerous prompt.

### Ablation: Backbone Comparison

| Backbone | Accuracy | F1 |
|---|---|---|
| BERT-base | 76.4% | 0.75 |
| RoBERTa-base | 78.9% | 0.78 |
| **DeBERTa-v3 (Ours)** | **81.3%** | **0.80** |

### Cross-Domain Generalisation

| Domain | Accuracy | F1 |
|---|---|---|
| General Knowledge | 82.1% | 0.79 |
| Science & Tech | 80.7% | 0.77 |
| Current Events | 78.5% | 0.75 |
| History | 83.2% | 0.80 |
| Abstract Reasoning | 79.8% | 0.76 |
| Specialised | 77.4% | 0.74 |

---

## Project Structure

```
hallucination-risk-prediction/
│
├── src/
│   ├── data/
│   │   ├── dataset.py          # PyTorch Dataset, data loading utilities
│   │   └── generate_prompts.py # Synthetic prompt generation pipeline
│   ├── labeling/
│   │   └── consensus.py        # Multi-model consensus labeling committee
│   ├── models/
│   │   ├── classifier.py       # DeBERTa-v3 + MLP classification head
│   │   └── baselines.py        # TF-IDF, keyword, prompt-length baselines
│   ├── training/
│   │   ├── trainer.py          # Training loop with early stopping
│   │   └── config.py           # Dataclass-based hyperparameter config
│   └── evaluation/
│       └── metrics.py          # Accuracy, F1, per-class recall, latency
│
├── scripts/
│   ├── train.py                # Entry point: train the classifier
│   ├── evaluate.py             # Entry point: evaluate on test set
│   ├── predict.py              # Entry point: run inference on new prompts
│   └── generate_dataset.py     # Entry point: build the labeled dataset
│
├── configs/
│   └── deberta_config.yaml     # All hyperparameters in one place
│
├── notebooks/
│   ├── 01_data_exploration.ipynb
│   └── 02_results_analysis.ipynb
│
├── tests/
│   ├── test_dataset.py
│   ├── test_model.py
│   └── test_metrics.py
│
├── requirements.txt
├── setup.py
└── README.md
```

---

## Setup

### 1. Clone the repository

```bash
git clone https://github.com/your-username/hallucination-risk-prediction.git
cd hallucination-risk-prediction
```

### 2. Create a virtual environment (recommended)

```bash
python -m venv venv
source venv/bin/activate        # Linux / macOS
# venv\Scripts\activate         # Windows
```

### 3. Install dependencies

```bash
pip install -r requirements.txt
```

---

## Usage

### Generate the labeled dataset

```bash
python scripts/generate_dataset.py --output data/prompts_labeled.csv --n-prompts 100000
```

### Train the classifier

```bash
python scripts/train.py --config configs/deberta_config.yaml
```

### Evaluate on the test set

```bash
python scripts/evaluate.py --checkpoint checkpoints/best_model.pt --data data/test.csv
```

### Predict risk for new prompts

```bash
python scripts/predict.py --prompt "What were the exact casualty figures in the 1823 Battle of X?"
# Output: {"risk": "High", "confidence": 0.91, "latency_ms": 11.8}
```

---

## Methodology

### Dataset Construction

A dataset of ~100,000 prompts was constructed with deliberate overrepresentation of edge cases (temporal ambiguity, obscure facts, numeric claims):

| Risk Category | Count | % |
|---|---|---|
| Low Risk | 30,000 | 30% |
| Medium Risk | 20,000 | 20% |
| High Risk | 50,000 | 50% |

### Consensus Labeling

Ground truth was obtained without human annotation via a **committee of three LLMs**. A prompt is labeled:
- **Low Risk** — all three models agree on the same answer
- **High Risk** — models disagree or produce fabricated information

### Model Architecture

- **Backbone**: `microsoft/deberta-v3-base` (184M parameters)
- **Head**: Dropout (p=0.1) → Linear layer → 3-class softmax
- **Optimizer**: AdamW, lr=2e-5
- **Batch size**: 32
- **Early stopping**: patience=2 epochs on validation loss
- **Training time**: ~3.5 hours on a single NVIDIA A100 (80GB)

---

## Citation

If you use this work, please cite:

```bibtex
@article{bhatt2026preinference,
  title     = {Pre-Inference Hallucination Risk Prediction in Large Language Models},
  author    = {Bhatt, Harsh and Dadhania, Avani},
  year      = {2026},
  institution = {LDRP Institute of Technology and Research, Gandhinagar, Gujarat, India}
}
```

---

## License

MIT License. See [LICENSE](LICENSE) for details.
