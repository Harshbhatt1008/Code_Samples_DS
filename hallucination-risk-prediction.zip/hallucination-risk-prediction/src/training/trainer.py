"""
trainer.py — Training loop for the DeBERTa hallucination risk classifier.

Features
~~~~~~~~
- AdamW optimiser with linear warmup schedule
- Early stopping on validation loss
- Best-model checkpointing
- Step-level logging
"""

from __future__ import annotations

import logging
import os
import time

import torch
from torch.optim import AdamW
from torch.utils.data import DataLoader
from transformers import get_linear_schedule_with_warmup

from src.training.config import TrainingConfig

logger = logging.getLogger(__name__)


class EarlyStopping:
    """
    Stops training if validation loss does not improve for ``patience`` epochs.

    Parameters
    ----------
    patience : int
        Number of epochs to wait before stopping.
    min_delta : float
        Minimum improvement to count as progress.
    """

    def __init__(self, patience: int = 2, min_delta: float = 1e-4) -> None:
        self.patience = patience
        self.min_delta = min_delta
        self._best_loss: float = float("inf")
        self._counter: int = 0
        self.should_stop: bool = False

    def step(self, val_loss: float) -> None:
        """Update internal state after each validation epoch."""
        if val_loss < self._best_loss - self.min_delta:
            self._best_loss = val_loss
            self._counter = 0
        else:
            self._counter += 1
            logger.info(
                "EarlyStopping: no improvement for %d / %d epochs",
                self._counter,
                self.patience,
            )
            if self._counter >= self.patience:
                self.should_stop = True


class Trainer:
    """
    Manages the full training lifecycle for the hallucination risk classifier.

    Parameters
    ----------
    model : torch.nn.Module
        The classifier to train.
    train_loader : DataLoader
    val_loader : DataLoader
    config : TrainingConfig
    device : str
        ``"cuda"`` or ``"cpu"``.
    """

    def __init__(
        self,
        model: torch.nn.Module,
        train_loader: DataLoader,
        val_loader: DataLoader,
        config: TrainingConfig,
        device: str = "cpu",
    ) -> None:
        self.model = model.to(device)
        self.train_loader = train_loader
        self.val_loader = val_loader
        self.config = config
        self.device = device

        total_steps = len(train_loader) * config.epochs
        warmup_steps = int(total_steps * config.warmup_ratio)

        self.optimizer = AdamW(
            model.parameters(),
            lr=config.learning_rate,
            weight_decay=config.weight_decay,
        )
        self.scheduler = get_linear_schedule_with_warmup(
            self.optimizer,
            num_warmup_steps=warmup_steps,
            num_training_steps=total_steps,
        )
        self.early_stopping = EarlyStopping(patience=config.patience)

        os.makedirs(config.checkpoint_dir, exist_ok=True)

    # ------------------------------------------------------------------
    # Public entry point
    # ------------------------------------------------------------------

    def train(self) -> dict[str, list[float]]:
        """
        Run the full training loop.

        Returns
        -------
        dict[str, list[float]]
            History with keys ``"train_loss"`` and ``"val_loss"``.
        """
        history: dict[str, list[float]] = {"train_loss": [], "val_loss": []}
        best_val_loss = float("inf")

        for epoch in range(1, self.config.epochs + 1):
            logger.info("=== Epoch %d / %d ===", epoch, self.config.epochs)

            train_loss = self._train_epoch(epoch)
            val_loss = self._validate_epoch()

            history["train_loss"].append(train_loss)
            history["val_loss"].append(val_loss)

            logger.info(
                "Epoch %d | train_loss=%.4f | val_loss=%.4f",
                epoch, train_loss, val_loss,
            )

            if val_loss < best_val_loss:
                best_val_loss = val_loss
                self._save_checkpoint(epoch, val_loss)
                logger.info("New best model saved (val_loss=%.4f)", val_loss)

            self.early_stopping.step(val_loss)
            if self.early_stopping.should_stop:
                logger.info("Early stopping triggered at epoch %d.", epoch)
                break

        return history

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _train_epoch(self, epoch: int) -> float:
        self.model.train()
        total_loss = 0.0

        for step, batch in enumerate(self.train_loader, start=1):
            batch = {k: v.to(self.device) for k, v in batch.items()}

            self.optimizer.zero_grad()
            outputs = self.model(**batch)
            loss = outputs.loss
            loss.backward()

            torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=1.0)
            self.optimizer.step()
            self.scheduler.step()

            total_loss += loss.item()

            if step % self.config.log_every_n_steps == 0:
                avg = total_loss / step
                logger.info("  Epoch %d | step %d | avg_loss=%.4f", epoch, step, avg)

        return total_loss / len(self.train_loader)

    @torch.no_grad()
    def _validate_epoch(self) -> float:
        self.model.eval()
        total_loss = 0.0

        for batch in self.val_loader:
            batch = {k: v.to(self.device) for k, v in batch.items()}
            outputs = self.model(**batch)
            total_loss += outputs.loss.item()

        return total_loss / len(self.val_loader)

    def _save_checkpoint(self, epoch: int, val_loss: float) -> None:
        path = os.path.join(self.config.checkpoint_dir, self.config.best_model_name)
        torch.save(
            {
                "epoch": epoch,
                "val_loss": val_loss,
                "model_state_dict": self.model.state_dict(),
                "config": self.model.config,
            },
            path,
        )
