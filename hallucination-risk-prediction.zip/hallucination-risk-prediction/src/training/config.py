"""
config.py — Hyperparameter configuration for the hallucination risk classifier.

All training parameters live here so that experiments are fully reproducible
without touching model or training code.
"""

from dataclasses import dataclass, field


@dataclass
class TrainingConfig:
    """Complete configuration for a single training run."""

    # --- Model ---
    model_name: str = "microsoft/deberta-v3-base"
    num_labels: int = 3          # Low / Medium / High
    dropout_prob: float = 0.1

    # --- Data ---
    data_path: str = "data/prompts_labeled.csv"
    test_size: float = 0.15
    val_size: float = 0.10
    max_length: int = 256        # Max token length for DeBERTa tokenizer
    random_seed: int = 42

    # --- Training ---
    epochs: int = 5
    batch_size: int = 32
    learning_rate: float = 2e-5
    weight_decay: float = 0.01   # AdamW decoupled weight decay
    warmup_ratio: float = 0.06

    # --- Early stopping ---
    patience: int = 2            # Stop if val loss does not improve for N epochs

    # --- Output ---
    checkpoint_dir: str = "checkpoints"
    best_model_name: str = "best_model.pt"
    log_every_n_steps: int = 100

    # --- Label mapping ---
    label2id: dict = field(default_factory=lambda: {
        "Low": 0,
        "Medium": 1,
        "High": 2,
    })
    id2label: dict = field(default_factory=lambda: {
        0: "Low",
        1: "Medium",
        2: "High",
    })

    @classmethod
    def from_yaml(cls, path: str) -> "TrainingConfig":
        """Load config from a YAML file, overriding defaults where specified."""
        import yaml

        with open(path, "r") as f:
            overrides = yaml.safe_load(f) or {}

        config = cls()
        for key, value in overrides.items():
            if hasattr(config, key):
                setattr(config, key, value)
            else:
                raise ValueError(f"Unknown config key: '{key}'")

        return config
