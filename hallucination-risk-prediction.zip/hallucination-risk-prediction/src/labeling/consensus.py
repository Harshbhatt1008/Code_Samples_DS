"""
consensus.py — Multi-model consensus labeling committee.

Ground truth labels are obtained by querying three independent LLMs on each
prompt. If all three agree on the same answer the prompt is Low Risk. If they
disagree or produce fabricated information it is marked High Risk.

This module is intentionally model-agnostic: swap in any callable that accepts
a prompt string and returns an answer string.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Callable

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------

@dataclass
class LabelingResult:
    """The outcome of running the consensus committee on a single prompt."""

    prompt: str
    answers: list[str]
    risk_label: str          # "Low" | "Medium" | "High"
    agreement: bool          # True if all models agreed
    model_names: list[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Core committee logic
# ---------------------------------------------------------------------------

class ConsensusCommittee:
    """
    Queries a list of LLM callables and derives a risk label from their
    level of agreement.

    Parameters
    ----------
    models : list[Callable[[str], str]]
        Ordered list of model callables. Each must accept a prompt string and
        return an answer string.
    model_names : list[str], optional
        Human-readable names for logging. Defaults to ["model_0", "model_1", …].
    similarity_threshold : float
        Minimum normalised-edit-distance similarity for two answers to be
        considered "in agreement". Default is 0.7.
    """

    def __init__(
        self,
        models: list[Callable[[str], str]],
        model_names: list[str] | None = None,
        similarity_threshold: float = 0.7,
    ) -> None:
        if len(models) < 2:
            raise ValueError("The committee requires at least two models.")

        self.models = models
        self.model_names = model_names or [f"model_{i}" for i in range(len(models))]
        self.similarity_threshold = similarity_threshold

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def label(self, prompt: str) -> LabelingResult:
        """
        Run the prompt through every model and derive a risk label.

        Parameters
        ----------
        prompt : str
            A single user query.

        Returns
        -------
        LabelingResult
        """
        answers = []
        for name, model in zip(self.model_names, self.models):
            try:
                answer = model(prompt)
                answers.append(answer)
                logger.debug("Model '%s' answered: %s", name, answer[:80])
            except Exception as exc:  # noqa: BLE001
                logger.warning("Model '%s' failed on prompt: %s", name, exc)
                answers.append("")  # Treat failure as an empty / wrong answer

        risk_label, agreement = self._derive_label(answers)
        return LabelingResult(
            prompt=prompt,
            answers=answers,
            risk_label=risk_label,
            agreement=agreement,
            model_names=self.model_names,
        )

    def label_batch(self, prompts: list[str]) -> list[LabelingResult]:
        """
        Label a list of prompts, logging progress every 1 000 samples.

        Parameters
        ----------
        prompts : list[str]

        Returns
        -------
        list[LabelingResult]
        """
        results = []
        for i, prompt in enumerate(prompts):
            results.append(self.label(prompt))
            if (i + 1) % 1_000 == 0:
                logger.info("Labeled %d / %d prompts", i + 1, len(prompts))
        return results

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _derive_label(self, answers: list[str]) -> tuple[str, bool]:
        """
        Compare answers pairwise to decide on a risk label.

        Decision rules
        ~~~~~~~~~~~~~~
        - All pairs agree  → ``"Low"``
        - Some disagreement → ``"Medium"``
        - Any answer is empty or majority disagree → ``"High"``
        """
        if any(a == "" for a in answers):
            return "High", False

        n = len(answers)
        agreement_matrix = [
            [self._answers_agree(answers[i], answers[j]) for j in range(n)]
            for i in range(n)
        ]

        total_pairs = n * (n - 1) / 2
        agreeing_pairs = sum(
            agreement_matrix[i][j]
            for i in range(n)
            for j in range(i + 1, n)
        )

        agreement_ratio = agreeing_pairs / total_pairs if total_pairs > 0 else 0.0

        if agreement_ratio == 1.0:
            return "Low", True
        if agreement_ratio >= 0.5:
            return "Medium", False
        return "High", False

    def _answers_agree(self, a: str, b: str) -> bool:
        """
        Return True if two answer strings are sufficiently similar.

        Uses a simple normalised character-overlap heuristic that avoids the
        overhead of a full sequence matcher for large batches.
        """
        a, b = a.strip().lower(), b.strip().lower()
        if a == b:
            return True
        if not a or not b:
            return False

        # Jaccard similarity over character 3-grams
        def ngrams(text: str, n: int = 3) -> set[str]:
            return {text[i : i + n] for i in range(len(text) - n + 1)}

        set_a, set_b = ngrams(a), ngrams(b)
        if not set_a or not set_b:
            return False

        intersection = len(set_a & set_b)
        union = len(set_a | set_b)
        similarity = intersection / union
        return similarity >= self.similarity_threshold
