"""
baselines.py — Lightweight baseline classifiers used in the ablation study.

Each baseline implements the same ``fit`` / ``predict`` interface so they can
be swapped into the evaluation loop without code changes.

Baselines
~~~~~~~~~
- ``PromptLengthBaseline``  : predicts risk from token count alone
- ``KeywordBaseline``       : matches a curated vocabulary of risk keywords
- ``TFIDFBaseline``         : TF-IDF features + Logistic Regression
"""

from __future__ import annotations

import re
from typing import Literal

import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline


RiskLabel = Literal["Low", "Medium", "High"]

# ---------------------------------------------------------------------------
# Prompt-Length Baseline
# ---------------------------------------------------------------------------

class PromptLengthBaseline:
    """
    Classifies risk purely based on the number of whitespace-separated tokens.

    Rationale: longer, more detailed questions tend to be higher risk.
    Thresholds are set heuristically on the training set.

    Parameters
    ----------
    low_threshold : int
        Prompts with fewer tokens than this are labeled Low Risk.
    high_threshold : int
        Prompts with more tokens than this are labeled High Risk.
    """

    def __init__(self, low_threshold: int = 8, high_threshold: int = 25) -> None:
        self.low_threshold = low_threshold
        self.high_threshold = high_threshold

    def fit(self, prompts: list[str], labels: list[str]) -> "PromptLengthBaseline":
        """No-op: this baseline has no learnable parameters."""
        return self

    def predict(self, prompts: list[str]) -> list[RiskLabel]:
        """Return a risk label for each prompt."""
        results = []
        for prompt in prompts:
            n_tokens = len(prompt.split())
            if n_tokens <= self.low_threshold:
                results.append("Low")
            elif n_tokens >= self.high_threshold:
                results.append("High")
            else:
                results.append("Medium")
        return results


# ---------------------------------------------------------------------------
# Keyword Baseline
# ---------------------------------------------------------------------------

# Risk keywords curated to reflect prompt patterns that correlate with
# hallucination: temporal specificity, obscure numerics, hedged questions.
_HIGH_RISK_KEYWORDS: frozenset[str] = frozenset({
    "exact", "precisely", "specific", "latest", "current", "recent",
    "today", "yesterday", "this year", "2023", "2024", "2025",
    "how many", "what percentage", "what is the population",
    "who exactly", "first", "original", "specific date",
    "legal", "law", "statute", "regulation", "medical", "diagnosis",
    "treatment", "drug", "dosage",
})

_LOW_RISK_KEYWORDS: frozenset[str] = frozenset({
    "write a poem", "story about", "explain", "what is", "define",
    "summarise", "describe", "how does", "what are the steps",
    "give me an example",
})


class KeywordBaseline:
    """
    Rule-based classifier using curated keyword sets.

    Parameters
    ----------
    high_risk_words : frozenset[str], optional
        Override the default high-risk keyword set.
    low_risk_words : frozenset[str], optional
        Override the default low-risk keyword set.
    """

    def __init__(
        self,
        high_risk_words: frozenset[str] | None = None,
        low_risk_words: frozenset[str] | None = None,
    ) -> None:
        self.high_risk_words = high_risk_words or _HIGH_RISK_KEYWORDS
        self.low_risk_words = low_risk_words or _LOW_RISK_KEYWORDS

    def fit(self, prompts: list[str], labels: list[str]) -> "KeywordBaseline":
        """No-op: keyword sets are defined at construction time."""
        return self

    def predict(self, prompts: list[str]) -> list[RiskLabel]:
        results = []
        for prompt in prompts:
            lower = prompt.lower()
            if any(kw in lower for kw in self.high_risk_words):
                results.append("High")
            elif any(kw in lower for kw in self.low_risk_words):
                results.append("Low")
            else:
                results.append("Medium")
        return results


# ---------------------------------------------------------------------------
# TF-IDF + Logistic Regression Baseline
# ---------------------------------------------------------------------------

class TFIDFBaseline:
    """
    Scikit-learn pipeline: TF-IDF vectoriser → Logistic Regression.

    Parameters
    ----------
    max_features : int
        Maximum vocabulary size for the TF-IDF vectoriser.
    ngram_range : tuple[int, int]
        (min_n, max_n) for n-gram extraction.
    C : float
        Inverse regularisation strength for Logistic Regression.
    max_iter : int
        Maximum solver iterations.
    """

    def __init__(
        self,
        max_features: int = 50_000,
        ngram_range: tuple[int, int] = (1, 2),
        C: float = 1.0,
        max_iter: int = 1_000,
    ) -> None:
        self._pipeline = Pipeline([
            (
                "tfidf",
                TfidfVectorizer(
                    max_features=max_features,
                    ngram_range=ngram_range,
                    sublinear_tf=True,
                    strip_accents="unicode",
                    analyzer="word",
                    token_pattern=r"\b[a-zA-Z]\w+\b",
                ),
            ),
            (
                "clf",
                LogisticRegression(C=C, max_iter=max_iter, class_weight="balanced"),
            ),
        ])

    def fit(self, prompts: list[str], labels: list[str]) -> "TFIDFBaseline":
        """
        Fit the TF-IDF + LR pipeline.

        Parameters
        ----------
        prompts : list[str]
        labels : list[str]
            String labels ("Low" / "Medium" / "High").

        Returns
        -------
        TFIDFBaseline
            Returns ``self`` for method chaining.
        """
        self._pipeline.fit(prompts, labels)
        return self

    def predict(self, prompts: list[str]) -> list[RiskLabel]:
        return list(self._pipeline.predict(prompts))

    def predict_proba(self, prompts: list[str]) -> np.ndarray:
        """Return class probability estimates of shape (n_samples, 3)."""
        return self._pipeline.predict_proba(prompts)
