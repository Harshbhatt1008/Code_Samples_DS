"""
classifier.py — DeBERTa-v3 hallucination risk classifier.

Architecture
~~~~~~~~~~~~
    DeBERTa-v3-base  →  [CLS] token embedding  →  Dropout  →  Linear  →  softmax
"""

from __future__ import annotations

import torch
import torch.nn as nn
from transformers import DebertaV2Model, DebertaV2PreTrainedModel
from transformers.modeling_outputs import SequenceClassifierOutput


class HallucinationRiskClassifier(DebertaV2PreTrainedModel):
    """
    DeBERTa-v3 with a linear classification head for 3-class risk prediction.

    Inheriting from ``DebertaV2PreTrainedModel`` gives us HuggingFace's
    ``from_pretrained`` / ``save_pretrained`` interface for free.

    Parameters
    ----------
    config : transformers.DebertaV2Config
        HuggingFace model config. ``config.num_labels`` must equal 3.
    dropout_prob : float
        Dropout probability applied before the classification head.
    """

    def __init__(self, config, dropout_prob: float = 0.1) -> None:
        super().__init__(config)
        self.num_labels = config.num_labels

        self.deberta = DebertaV2Model(config)
        self.dropout = nn.Dropout(dropout_prob)
        self.classifier = nn.Linear(config.hidden_size, config.num_labels)

        # Initialise weights and apply final processing
        self.post_init()

    def forward(
        self,
        input_ids: torch.Tensor | None = None,
        attention_mask: torch.Tensor | None = None,
        labels: torch.Tensor | None = None,
        **kwargs,
    ) -> SequenceClassifierOutput:
        """
        Forward pass.

        Parameters
        ----------
        input_ids : torch.Tensor of shape (batch, seq_len)
        attention_mask : torch.Tensor of shape (batch, seq_len)
        labels : torch.Tensor of shape (batch,), optional
            Integer class indices. If provided, cross-entropy loss is computed.

        Returns
        -------
        SequenceClassifierOutput
            ``.loss`` is set when ``labels`` is provided.
            ``.logits`` has shape (batch, num_labels).
        """
        outputs = self.deberta(
            input_ids=input_ids,
            attention_mask=attention_mask,
            **kwargs,
        )

        # Use the [CLS] token representation (first token)
        cls_embedding = outputs.last_hidden_state[:, 0, :]
        cls_embedding = self.dropout(cls_embedding)
        logits = self.classifier(cls_embedding)

        loss = None
        if labels is not None:
            loss_fn = nn.CrossEntropyLoss()
            loss = loss_fn(logits.view(-1, self.num_labels), labels.view(-1))

        return SequenceClassifierOutput(
            loss=loss,
            logits=logits,
            hidden_states=outputs.hidden_states,
            attentions=outputs.attentions,
        )


# ---------------------------------------------------------------------------
# Convenience: load a trained checkpoint for inference
# ---------------------------------------------------------------------------

def load_classifier(checkpoint_path: str, device: str = "cpu") -> HallucinationRiskClassifier:
    """
    Load a saved classifier from a ``.pt`` checkpoint file.

    Parameters
    ----------
    checkpoint_path : str
        Path to the file saved by ``torch.save``.
    device : str
        Target device, e.g. ``"cpu"`` or ``"cuda"``.

    Returns
    -------
    HallucinationRiskClassifier
        Model in evaluation mode on the requested device.
    """
    checkpoint = torch.load(checkpoint_path, map_location=device)
    model = HallucinationRiskClassifier(checkpoint["config"])
    model.load_state_dict(checkpoint["model_state_dict"])
    model.to(device)
    model.eval()
    return model
