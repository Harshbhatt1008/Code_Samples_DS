"""hallucination-risk-prediction — pre-inference hallucination risk prediction."""
