"""
dataset.py — PyTorch Dataset and loading utilities for hallucination risk data.

Each sample is a (prompt_text, risk_label) pair. Labels are:
    0 = Low Risk | 1 = Medium Risk | 2 = High Risk
"""

from __future__ import annotations

import pandas as pd
import torch
from torch.utils.data import Dataset
from transformers import PreTrainedTokenizerBase


LABEL2ID = {"Low": 0, "Medium": 1, "High": 2}
ID2LABEL = {v: k for k, v in LABEL2ID.items()}


class HallucinationRiskDataset(Dataset):
    """
    Wraps a CSV of prompts and risk labels as a PyTorch Dataset.

    Expected CSV columns:
        - ``prompt``  : str  — the user query
        - ``risk``    : str  — one of {"Low", "Medium", "High"}

    Parameters
    ----------
    prompts : list[str]
        Raw prompt strings.
    labels : list[int]
        Integer-encoded risk labels (0 / 1 / 2).
    tokenizer : PreTrainedTokenizerBase
        A HuggingFace tokenizer compatible with the chosen backbone.
    max_length : int
        Maximum token sequence length passed to the tokenizer.
    """

    def __init__(
        self,
        prompts: list[str],
        labels: list[int],
        tokenizer: PreTrainedTokenizerBase,
        max_length: int = 256,
    ) -> None:
        self.prompts = prompts
        self.labels = labels
        self.tokenizer = tokenizer
        self.max_length = max_length

    # ------------------------------------------------------------------
    # Required Dataset interface
    # ------------------------------------------------------------------

    def __len__(self) -> int:
        return len(self.prompts)

    def __getitem__(self, idx: int) -> dict[str, torch.Tensor]:
        encoding = self.tokenizer(
            self.prompts[idx],
            max_length=self.max_length,
            padding="max_length",
            truncation=True,
            return_tensors="pt",
        )
        return {
            "input_ids": encoding["input_ids"].squeeze(0),
            "attention_mask": encoding["attention_mask"].squeeze(0),
            "labels": torch.tensor(self.labels[idx], dtype=torch.long),
        }


# ------------------------------------------------------------------
# Convenience loaders
# ------------------------------------------------------------------

def load_csv(path: str) -> pd.DataFrame:
    """
    Load a labeled prompt CSV and validate expected columns.

    Parameters
    ----------
    path : str
        Path to the CSV file.

    Returns
    -------
    pd.DataFrame
        DataFrame with at least ``prompt`` and ``risk`` columns.

    Raises
    ------
    ValueError
        If required columns are missing or labels contain unknown values.
    """
    df = pd.read_csv(path)

    required_columns = {"prompt", "risk"}
    missing = required_columns - set(df.columns)
    if missing:
        raise ValueError(f"CSV is missing required columns: {missing}")

    unknown_labels = set(df["risk"].unique()) - set(LABEL2ID.keys())
    if unknown_labels:
        raise ValueError(f"Unknown risk labels in dataset: {unknown_labels}")

    df["label_id"] = df["risk"].map(LABEL2ID)
    return df


def split_dataframe(
    df: pd.DataFrame,
    test_size: float = 0.15,
    val_size: float = 0.10,
    random_seed: int = 42,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """
    Split a DataFrame into train / validation / test sets.

    Parameters
    ----------
    df : pd.DataFrame
    test_size : float
        Fraction of data reserved for the test set.
    val_size : float
        Fraction of *remaining* data reserved for validation.
    random_seed : int

    Returns
    -------
    tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]
        (train_df, val_df, test_df)
    """
    from sklearn.model_selection import train_test_split

    train_val, test = train_test_split(
        df, test_size=test_size, random_state=random_seed, stratify=df["risk"]
    )
    train, val = train_test_split(
        train_val, test_size=val_size, random_state=random_seed, stratify=train_val["risk"]
    )
    return train.reset_index(drop=True), val.reset_index(drop=True), test.reset_index(drop=True)
