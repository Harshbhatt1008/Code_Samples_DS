"""
metrics.py — Evaluation utilities for the hallucination risk classifier.

Provides
~~~~~~~~
- ``compute_metrics``   : accuracy, precision, recall, F1 (macro + per-class)
- ``latency_benchmark`` : wall-clock inference time measurement
- ``print_report``      : pretty-print a full evaluation summary
"""

from __future__ import annotations

import time
from typing import Sequence

import numpy as np
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
)


LABEL_NAMES = ["Low", "Medium", "High"]


# ---------------------------------------------------------------------------
# Core metrics
# ---------------------------------------------------------------------------

def compute_metrics(
    y_true: Sequence[int | str],
    y_pred: Sequence[int | str],
    label_names: list[str] = LABEL_NAMES,
) -> dict[str, float]:
    """
    Compute classification metrics for a set of predictions.

    Parameters
    ----------
    y_true : sequence of int or str
        Ground-truth labels.
    y_pred : sequence of int or str
        Predicted labels.
    label_names : list[str]
        Human-readable class names in label-index order.

    Returns
    -------
    dict[str, float]
        Keys: ``accuracy``, ``precision_macro``, ``recall_macro``,
        ``f1_macro``, plus per-class ``precision_<label>``,
        ``recall_<label>``, ``f1_<label>``.
    """
    metrics: dict[str, float] = {
        "accuracy": accuracy_score(y_true, y_pred),
        "precision_macro": precision_score(y_true, y_pred, average="macro", zero_division=0),
        "recall_macro": recall_score(y_true, y_pred, average="macro", zero_division=0),
        "f1_macro": f1_score(y_true, y_pred, average="macro", zero_division=0),
    }

    per_class_precision = precision_score(
        y_true, y_pred, average=None, labels=label_names, zero_division=0
    )
    per_class_recall = recall_score(
        y_true, y_pred, average=None, labels=label_names, zero_division=0
    )
    per_class_f1 = f1_score(
        y_true, y_pred, average=None, labels=label_names, zero_division=0
    )

    for label, p, r, f in zip(label_names, per_class_precision, per_class_recall, per_class_f1):
        metrics[f"precision_{label}"] = float(p)
        metrics[f"recall_{label}"] = float(r)
        metrics[f"f1_{label}"] = float(f)

    return metrics


# ---------------------------------------------------------------------------
# Latency benchmark
# ---------------------------------------------------------------------------

def latency_benchmark(
    predict_fn,
    prompts: list[str],
    n_warmup: int = 10,
) -> dict[str, float]:
    """
    Measure wall-clock inference latency for a prediction function.

    Parameters
    ----------
    predict_fn : callable
        A function that accepts a list of prompt strings and returns predictions.
    prompts : list[str]
        Prompts to benchmark on.
    n_warmup : int
        Number of warm-up calls before timing begins (to prime GPU / JIT).

    Returns
    -------
    dict[str, float]
        Keys: ``mean_ms``, ``std_ms``, ``p50_ms``, ``p95_ms``, ``p99_ms``.
    """
    # Warm up
    for prompt in prompts[:n_warmup]:
        predict_fn([prompt])

    latencies_ms: list[float] = []
    for prompt in prompts:
        t0 = time.perf_counter()
        predict_fn([prompt])
        elapsed_ms = (time.perf_counter() - t0) * 1_000
        latencies_ms.append(elapsed_ms)

    arr = np.array(latencies_ms)
    return {
        "mean_ms": float(arr.mean()),
        "std_ms": float(arr.std()),
        "p50_ms": float(np.percentile(arr, 50)),
        "p95_ms": float(np.percentile(arr, 95)),
        "p99_ms": float(np.percentile(arr, 99)),
    }


# ---------------------------------------------------------------------------
# Pretty-print report
# ---------------------------------------------------------------------------

def print_report(
    y_true: Sequence[int | str],
    y_pred: Sequence[int | str],
    label_names: list[str] = LABEL_NAMES,
    latency: dict[str, float] | None = None,
) -> None:
    """
    Print a human-readable evaluation summary to stdout.

    Parameters
    ----------
    y_true, y_pred : sequences of labels
    label_names : list[str]
    latency : dict[str, float], optional
        Output of ``latency_benchmark``; printed if provided.
    """
    metrics = compute_metrics(y_true, y_pred, label_names)

    print("\n" + "=" * 60)
    print("  HALLUCINATION RISK CLASSIFIER — EVALUATION REPORT")
    print("=" * 60)
    print(f"  Accuracy  : {metrics['accuracy']:.4f}")
    print(f"  Precision : {metrics['precision_macro']:.4f}  (macro)")
    print(f"  Recall    : {metrics['recall_macro']:.4f}  (macro)")
    print(f"  F1        : {metrics['f1_macro']:.4f}  (macro)")

    print("\n  Per-class breakdown:")
    header = f"  {'Label':<10} {'Precision':>10} {'Recall':>10} {'F1':>10}"
    print(header)
    print("  " + "-" * (len(header) - 2))
    for label in label_names:
        print(
            f"  {label:<10} "
            f"{metrics[f'precision_{label}']:>10.4f} "
            f"{metrics[f'recall_{label}']:>10.4f} "
            f"{metrics[f'f1_{label}']:>10.4f}"
        )

    print("\n  Confusion matrix (rows=true, cols=pred):")
    cm = confusion_matrix(y_true, y_pred, labels=label_names)
    col_width = max(len(n) for n in label_names) + 2
    header_row = " " * col_width + "".join(f"{n:>{col_width}}" for n in label_names)
    print("  " + header_row)
    for label, row in zip(label_names, cm):
        row_str = f"{label:<{col_width}}" + "".join(f"{v:>{col_width}}" for v in row)
        print("  " + row_str)

    if latency:
        print(f"\n  Latency  (mean): {latency['mean_ms']:.1f} ms")
        print(f"  Latency  (p95) : {latency['p95_ms']:.1f} ms")
        print(f"  Latency  (p99) : {latency['p99_ms']:.1f} ms")

    print("=" * 60 + "\n")
