"""tests/test_dataset.py — Unit tests for data loading utilities."""

import io
import unittest
from unittest.mock import patch

import pandas as pd
from transformers import DebertaV2Tokenizer

from src.data.dataset import (
    LABEL2ID,
    HallucinationRiskDataset,
    load_csv,
    split_dataframe,
)

# Minimal mock tokenizer that avoids a network download in CI
class _MockTokenizer:
    """Stub tokenizer that returns fixed-shape tensors."""

    def __call__(self, text, max_length=256, padding=None, truncation=None, return_tensors=None):
        import torch
        return {
            "input_ids": torch.zeros(1, max_length, dtype=torch.long),
            "attention_mask": torch.ones(1, max_length, dtype=torch.long),
        }


class TestLoadCSV(unittest.TestCase):

    def _make_csv(self, rows: list[dict]) -> str:
        df = pd.DataFrame(rows)
        return df.to_csv(index=False)

    def test_valid_csv_loads_correctly(self):
        csv_content = self._make_csv([
            {"prompt": "What is Python?", "risk": "Low"},
            {"prompt": "List exact tax rates for 2024.", "risk": "High"},
        ])
        with patch("builtins.open", unittest.mock.mock_open(read_data=csv_content)):
            with patch("pandas.read_csv", return_value=pd.read_csv(io.StringIO(csv_content))):
                df = load_csv("fake_path.csv")

        self.assertIn("label_id", df.columns)
        self.assertEqual(df.loc[0, "label_id"], LABEL2ID["Low"])
        self.assertEqual(df.loc[1, "label_id"], LABEL2ID["High"])

    def test_missing_column_raises_value_error(self):
        bad_df = pd.DataFrame({"prompt": ["hello"]})
        with patch("pandas.read_csv", return_value=bad_df):
            with self.assertRaises(ValueError, msg="Missing 'risk' column should raise."):
                load_csv("bad.csv")

    def test_unknown_label_raises_value_error(self):
        bad_df = pd.DataFrame({"prompt": ["hello"], "risk": ["Unknown"]})
        with patch("pandas.read_csv", return_value=bad_df):
            with self.assertRaises(ValueError):
                load_csv("bad.csv")


class TestSplitDataframe(unittest.TestCase):

    def _make_df(self, n: int = 200) -> pd.DataFrame:
        """Build a balanced synthetic dataset."""
        import numpy as np
        labels = (["Low"] * (n // 3) + ["Medium"] * (n // 3) + ["High"] * (n // 3))[:n]
        return pd.DataFrame({"prompt": [f"prompt_{i}" for i in range(n)], "risk": labels})

    def test_split_sizes_are_correct(self):
        df = self._make_df(200)
        train, val, test = split_dataframe(df, test_size=0.15, val_size=0.10)
        total = len(train) + len(val) + len(test)
        self.assertEqual(total, len(df))
        self.assertAlmostEqual(len(test) / len(df), 0.15, delta=0.05)

    def test_no_overlap_between_splits(self):
        df = self._make_df(300)
        train, val, test = split_dataframe(df)
        train_idx = set(train.index)
        val_idx = set(val.index)
        test_idx = set(test.index)
        self.assertTrue(train_idx.isdisjoint(val_idx))
        self.assertTrue(train_idx.isdisjoint(test_idx))
        self.assertTrue(val_idx.isdisjoint(test_idx))


class TestHallucinationRiskDataset(unittest.TestCase):

    def setUp(self):
        self.prompts = ["What is the capital of France?", "Exact 2024 birth stats?"]
        self.labels = [0, 2]
        self.tokenizer = _MockTokenizer()

    def test_len(self):
        ds = HallucinationRiskDataset(self.prompts, self.labels, self.tokenizer)
        self.assertEqual(len(ds), 2)

    def test_item_keys(self):
        ds = HallucinationRiskDataset(self.prompts, self.labels, self.tokenizer)
        item = ds[0]
        self.assertIn("input_ids", item)
        self.assertIn("attention_mask", item)
        self.assertIn("labels", item)

    def test_label_value(self):
        import torch
        ds = HallucinationRiskDataset(self.prompts, self.labels, self.tokenizer)
        self.assertEqual(ds[1]["labels"].item(), 2)


if __name__ == "__main__":
    unittest.main()
