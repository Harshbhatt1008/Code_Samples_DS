"""tests/test_metrics.py — Unit tests for evaluation metrics."""

import unittest

from src.evaluation.metrics import compute_metrics, latency_benchmark


class TestComputeMetrics(unittest.TestCase):

    def test_perfect_predictions(self):
        labels = ["Low", "Medium", "High", "Low", "High"]
        metrics = compute_metrics(labels, labels)
        self.assertAlmostEqual(metrics["accuracy"], 1.0)
        self.assertAlmostEqual(metrics["f1_macro"], 1.0)

    def test_all_wrong(self):
        y_true = ["Low", "Low", "Low"]
        y_pred = ["High", "High", "High"]
        metrics = compute_metrics(y_true, y_pred)
        self.assertAlmostEqual(metrics["accuracy"], 0.0)

    def test_metric_keys_present(self):
        y_true = ["Low", "Medium", "High"]
        y_pred = ["Low", "High", "High"]
        metrics = compute_metrics(y_true, y_pred)
        for key in ("accuracy", "precision_macro", "recall_macro", "f1_macro"):
            self.assertIn(key, metrics)
        for label in ("Low", "Medium", "High"):
            for metric in ("precision", "recall", "f1"):
                self.assertIn(f"{metric}_{label}", metrics)

    def test_values_in_valid_range(self):
        y_true = ["Low", "High", "Medium", "High", "Low"]
        y_pred = ["Low", "Medium", "Medium", "High", "High"]
        metrics = compute_metrics(y_true, y_pred)
        for v in metrics.values():
            self.assertGreaterEqual(v, 0.0)
            self.assertLessEqual(v, 1.0)


class TestLatencyBenchmark(unittest.TestCase):

    def test_returns_expected_keys(self):
        def fast_predict(prompts):
            return ["Low"] * len(prompts)

        result = latency_benchmark(fast_predict, ["hello"] * 20, n_warmup=5)
        for key in ("mean_ms", "std_ms", "p50_ms", "p95_ms", "p99_ms"):
            self.assertIn(key, result)

    def test_mean_is_non_negative(self):
        def fast_predict(prompts):
            pass

        result = latency_benchmark(fast_predict, ["test"] * 10, n_warmup=2)
        self.assertGreaterEqual(result["mean_ms"], 0.0)


if __name__ == "__main__":
    unittest.main()
