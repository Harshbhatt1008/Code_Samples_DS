"""
predict.py — Run inference on new prompts using a trained checkpoint.

Usage
-----
    # Single prompt
    python scripts/predict.py --checkpoint checkpoints/best_model.pt \
        --prompt "What were the exact casualty figures in the 1823 Battle of X?"

    # Batch from a text file (one prompt per line)
    python scripts/predict.py --checkpoint checkpoints/best_model.pt \
        --file prompts.txt --output predictions.csv
"""

from __future__ import annotations

import argparse
import json
import time

import pandas as pd
import torch
from transformers import DebertaV2Tokenizer

from src.models.classifier import load_classifier
from src.training.config import TrainingConfig


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Predict hallucination risk for prompts.")
    parser.add_argument("--checkpoint", type=str, required=True)
    parser.add_argument("--prompt", type=str, default=None, help="Single prompt string.")
    parser.add_argument("--file", type=str, default=None, help="Text file with one prompt per line.")
    parser.add_argument("--output", type=str, default=None, help="Output CSV path for batch mode.")
    parser.add_argument("--config", type=str, default="configs/deberta_config.yaml")
    parser.add_argument("--device", type=str, default="cpu")
    return parser.parse_args()


@torch.no_grad()
def predict(
    prompts: list[str],
    model,
    tokenizer: DebertaV2Tokenizer,
    max_length: int,
    device: str,
    id2label: dict[int, str],
) -> list[dict]:
    """
    Run inference on a list of prompts and return structured results.

    Parameters
    ----------
    prompts : list[str]
    model : HallucinationRiskClassifier
    tokenizer : DebertaV2Tokenizer
    max_length : int
    device : str
    id2label : dict[int, str]

    Returns
    -------
    list[dict]
        Each dict has keys: ``prompt``, ``risk``, ``confidence``, ``latency_ms``.
    """
    results = []
    model.eval()

    for prompt in prompts:
        encoding = tokenizer(
            prompt,
            max_length=max_length,
            padding="max_length",
            truncation=True,
            return_tensors="pt",
        )
        encoding = {k: v.to(device) for k, v in encoding.items()}

        t0 = time.perf_counter()
        outputs = model(**encoding)
        elapsed_ms = (time.perf_counter() - t0) * 1_000

        probs = torch.softmax(outputs.logits, dim=-1).squeeze()
        pred_id = probs.argmax().item()
        confidence = probs[pred_id].item()

        results.append({
            "prompt": prompt,
            "risk": id2label[pred_id],
            "confidence": round(confidence, 4),
            "latency_ms": round(elapsed_ms, 2),
        })

    return results


def main() -> None:
    args = parse_args()
    config = TrainingConfig.from_yaml(args.config)

    model = load_classifier(args.checkpoint, device=args.device)
    tokenizer = DebertaV2Tokenizer.from_pretrained(config.model_name)

    if args.prompt:
        results = predict(
            [args.prompt], model, tokenizer, config.max_length, args.device, config.id2label
        )
        print(json.dumps(results[0], indent=2))

    elif args.file:
        with open(args.file) as f:
            prompts = [line.strip() for line in f if line.strip()]

        results = predict(
            prompts, model, tokenizer, config.max_length, args.device, config.id2label
        )

        df = pd.DataFrame(results)
        out_path = args.output or "predictions.csv"
        df.to_csv(out_path, index=False)
        print(f"Saved {len(results)} predictions to {out_path}")
        print(df["risk"].value_counts().to_string())

    else:
        print("Provide --prompt or --file. Run with --help for usage.")


if __name__ == "__main__":
    main()
