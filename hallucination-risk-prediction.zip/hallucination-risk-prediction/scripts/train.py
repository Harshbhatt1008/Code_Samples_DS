"""
train.py — Entry point for training the hallucination risk classifier.

Usage
-----
    python scripts/train.py --config configs/deberta_config.yaml
    python scripts/train.py --config configs/deberta_config.yaml --device cuda
"""

import argparse
import logging
import random

import numpy as np
import torch
from torch.utils.data import DataLoader
from transformers import DebertaV2Config, DebertaV2Tokenizer

from src.data.dataset import HallucinationRiskDataset, load_csv, split_dataframe
from src.models.classifier import HallucinationRiskClassifier
from src.training.config import TrainingConfig
from src.training.trainer import Trainer

logging.basicConfig(
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)


def set_seed(seed: int) -> None:
    """Fix random seeds for reproducibility."""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Train the hallucination risk classifier.")
    parser.add_argument(
        "--config",
        type=str,
        default="configs/deberta_config.yaml",
        help="Path to the YAML config file.",
    )
    parser.add_argument(
        "--device",
        type=str,
        default="cuda" if torch.cuda.is_available() else "cpu",
        help="Device to train on (default: cuda if available, else cpu).",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()

    logger.info("Loading config from: %s", args.config)
    config = TrainingConfig.from_yaml(args.config)
    set_seed(config.random_seed)

    logger.info("Loading data from: %s", config.data_path)
    df = load_csv(config.data_path)
    train_df, val_df, _ = split_dataframe(
        df,
        test_size=config.test_size,
        val_size=config.val_size,
        random_seed=config.random_seed,
    )
    logger.info(
        "Split sizes — train: %d | val: %d", len(train_df), len(val_df)
    )

    logger.info("Loading tokenizer: %s", config.model_name)
    tokenizer = DebertaV2Tokenizer.from_pretrained(config.model_name)

    train_dataset = HallucinationRiskDataset(
        prompts=train_df["prompt"].tolist(),
        labels=train_df["label_id"].tolist(),
        tokenizer=tokenizer,
        max_length=config.max_length,
    )
    val_dataset = HallucinationRiskDataset(
        prompts=val_df["prompt"].tolist(),
        labels=val_df["label_id"].tolist(),
        tokenizer=tokenizer,
        max_length=config.max_length,
    )

    train_loader = DataLoader(train_dataset, batch_size=config.batch_size, shuffle=True)
    val_loader = DataLoader(val_dataset, batch_size=config.batch_size)

    logger.info("Initialising model: %s", config.model_name)
    model_config = DebertaV2Config.from_pretrained(
        config.model_name,
        num_labels=config.num_labels,
        id2label=config.id2label,
        label2id=config.label2id,
    )
    model = HallucinationRiskClassifier.from_pretrained(
        config.model_name,
        config=model_config,
        ignore_mismatched_sizes=True,
    )

    trainer = Trainer(
        model=model,
        train_loader=train_loader,
        val_loader=val_loader,
        config=config,
        device=args.device,
    )

    logger.info("Starting training on device: %s", args.device)
    history = trainer.train()
    logger.info("Training complete. Best checkpoint saved to: %s", config.checkpoint_dir)


if __name__ == "__main__":
    main()
