"""
evaluate.py — Evaluate a trained checkpoint on the held-out test set.

Usage
-----
    python scripts/evaluate.py \
        --checkpoint checkpoints/best_model.pt \
        --data data/test.csv \
        --benchmark-latency
"""

from __future__ import annotations

import argparse

import torch
from torch.utils.data import DataLoader
from transformers import DebertaV2Tokenizer

from src.data.dataset import LABEL_NAMES, HallucinationRiskDataset, load_csv
from src.evaluation.metrics import latency_benchmark, print_report
from src.models.classifier import load_classifier
from src.training.config import TrainingConfig


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Evaluate the hallucination risk classifier.")
    parser.add_argument("--checkpoint", type=str, required=True)
    parser.add_argument("--data", type=str, required=True, help="Path to test CSV.")
    parser.add_argument("--config", type=str, default="configs/deberta_config.yaml")
    parser.add_argument("--device", type=str, default="cpu")
    parser.add_argument(
        "--benchmark-latency",
        action="store_true",
        help="Run latency benchmark after evaluation.",
    )
    return parser.parse_args()


@torch.no_grad()
def evaluate(model, loader: DataLoader, device: str, id2label: dict) -> tuple[list, list]:
    """Collect all predictions and ground-truth labels from a DataLoader."""
    model.eval()
    y_true, y_pred = [], []

    for batch in loader:
        batch = {k: v.to(device) for k, v in batch.items()}
        labels = batch.pop("labels")
        outputs = model(**batch)
        preds = outputs.logits.argmax(dim=-1)

        y_true.extend([id2label[i.item()] for i in labels])
        y_pred.extend([id2label[i.item()] for i in preds])

    return y_true, y_pred


def main() -> None:
    args = parse_args()
    config = TrainingConfig.from_yaml(args.config)

    model = load_classifier(args.checkpoint, device=args.device)
    tokenizer = DebertaV2Tokenizer.from_pretrained(config.model_name)

    df = load_csv(args.data)
    dataset = HallucinationRiskDataset(
        prompts=df["prompt"].tolist(),
        labels=df["label_id"].tolist(),
        tokenizer=tokenizer,
        max_length=config.max_length,
    )
    loader = DataLoader(dataset, batch_size=config.batch_size)

    y_true, y_pred = evaluate(model, loader, args.device, config.id2label)

    latency = None
    if args.benchmark_latency:
        sample_prompts = df["prompt"].sample(min(200, len(df))).tolist()

        def predict_fn(prompts):
            enc = tokenizer(
                prompts,
                max_length=config.max_length,
                padding="max_length",
                truncation=True,
                return_tensors="pt",
            )
            with torch.no_grad():
                model(**{k: v.to(args.device) for k, v in enc.items()})

        latency = latency_benchmark(predict_fn, sample_prompts)

    print_report(y_true, y_pred, label_names=LABEL_NAMES, latency=latency)


if __name__ == "__main__":
    main()
